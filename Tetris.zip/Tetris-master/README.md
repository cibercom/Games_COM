# Tetris
My Tetris game version developed in RIA (Rich Internet Applications) subject

Juego del Tetris desarrollado en la asignatura de DAWE (Desarrollo de Aplicaciones Web Enriquecidas)
cursada en EUITI Bilbao. 
