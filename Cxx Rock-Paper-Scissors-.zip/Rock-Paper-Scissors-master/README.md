# **ROCK, PAPER, SCISSORS BY ZABE**

## Made in C
Pretty simple: it's just you and your console, in a romantic session of playing rock, paper and scissors.
