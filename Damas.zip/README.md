# Checkers
Checkers browser game for co-op player vs. player. This project is perfect to replicate if you want to better understand the basics of JS and how it talks to HTML (the DOM).

* Written using vanilla:
  * HTML
  * CSS
  * JavaScript

[Click here if you would like to play the game](https://ryanbranco.github.io/Checkers/)

Screenshots:

![checkers game](Images/checkersgame.png "Checkers")

![win](Images/checkerswin.png "Checkers win")
