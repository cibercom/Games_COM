#include <iostream>
#include <ncurses.h>

char board[3][3] = { {'1', '2', '3'}, {'4', '5', '6'}, {'7', '8', '9'} };
char current_player = 'X';
int choice;
int row, col;

void draw_board() {
    clear();
    printw("=== TIC TAC TOE ===\n\n");
    printw("     |     |     \n");
    printw("  %c  |  %c  |  %c  \n", board[0][0], board[0][1], board[0][2]);
    printw("_____|_____|_____\n");
    printw("     |     |     \n");
    printw("  %c  |  %c  |  %c  \n", board[1][0], board[1][1], board[1][2]);
    printw("_____|_____|_____\n");
    printw("     |     |     \n");
    printw("  %c  |  %c  |  %c  \n", board[2][0], board[2][1], board[2][2]);
    printw("     |     |     \n\n");
    refresh();
}

bool check_win() {
    // Check rows and columns
    for(int i = 0; i < 3; i++) {
        if(board[i][0] == board[i][1] && board[i][1] == board[i][2]) return true;
        if(board[0][i] == board[1][i] && board[1][i] == board[2][i]) return true;
    }
    // Check diagonals
    if(board[0][0] == board[1][1] && board[1][1] == board[2][2]) return true;
    if(board[0][2] == board[1][1] && board[1][1] == board[2][0]) return true;
    
    return false;
}

bool check_draw() {
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            if(board[i][j] != 'X' && board[i][j] != 'O') return false;
        }
    }
    return true;
}

int main() {
    // Initialize ncurses screen
    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);

    while(true) {
        draw_board();
        printw("Player %c, enter a number (1-9): ", current_player);
        
        // Wait for player to type their choice
        choice = getch() - '0'; 
        
        // Convert number to 2D array coordinates
        row = (choice - 1) / 3;
        col = (choice - 1) % 3;
        
        // Validate input
        if(choice >= 1 && choice <= 9 && board[row][col] != 'X' && board[row][col] != 'O') {
            board[row][col] = current_player;
            
            if(check_win()) {
                draw_board();
                printw("Player %c WINS! Press any key to exit.", current_player);
                getch();
                break;
            }
            
            if(check_draw()) {
                draw_board();
                printw("It's a DRAW! Press any key to exit.");
                getch();
                break;
            }
            
            // Switch player
            current_player = (current_player == 'X') ? 'O' : 'X';
        } else {
            printw("\nInvalid move! Press any key to try again.");
            getch();
        }
    }

    // Terminate ncurses
    endwin();
    return 0;
}