#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <cmath>

int main() {
    // Configurar ventana (tamaño emulado para celular)
    sf::RenderWindow window(sf::VideoMode(800, 1200), "Space vs CPU");
    window.setFramerateLimit(60);

    // Nave del jugador (navegación táctil)
    sf::RectangleShape player(sf::Vector2f(80.0f, 80.0f));
    player.setFillColor(sf::Color::Blue);
    player.setPosition(400.0f, 1000.0f);

    // Nave de la CPU (IA básica)
    sf::RectangleShape cpu(sf::Vector2f(80.0f, 80.0f));
    cpu.setFillColor(sf::Color::Red);
    cpu.setPosition(400.0f, 100.0f);
    float cpuSpeed = 5.0f; // Velocidad de la CPU

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        // --- LÓGICA TÁCTIL (JUGADOR) ---
        // Se detecta si hay un dedo tocando la pantalla (dedo índice = 0)
        if (sf::Touch::isDown(0)) {
            sf::Vector2i touchPos = sf::Touch::getPosition(0, window);
            // Centrar la nave donde se encuentra el toque
            player.setPosition(touchPos.x - player.getSize().x / 2, player.getPosition().y);
        }

        // --- LÓGICA DE LA CPU ---
        // La CPU intenta seguir la posición X del jugador
        if (cpu.getPosition().x < player.getPosition().x) {
            cpu.move(cpuSpeed, 0.0f);
        } else if (cpu.getPosition().x > player.getPosition().x) {
            cpu.move(-cpuSpeed, 0.0f);
        }

        // --- RENDERIZADO ---
        window.clear();
        window.draw(player);
        window.draw(cpu);
        window.display();
    }

    return 0;
}