#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>

#define WIDTH 60
#define HEIGHT 20

int ballX, ballY;
int ballDirX = 1, ballDirY = 1;
int playerY;
int computerY;
int scorePlayer = 0, scoreComputer = 0;
int gameOver = 0;

void setup() {
    ballX = WIDTH / 2;
    ballY = HEIGHT / 2;
    playerY = HEIGHT / 2 - 2;
    computerY = HEIGHT / 2 - 2;
}

void draw() {
    system("cls"); // Limpia la pantalla (usa "clear" si compilas en Linux/Mac)
    for (int i = 0; i < WIDTH + 2; i++) printf("#");
    printf("\n");

    for (int y = 0; y < HEIGHT; y++) {
        for (int x = 0; x < WIDTH; x++) {
            // Dibuja los límites laterales
            if (x == 0) printf("#");

            // Dibuja la pelota
            if (x == ballX && y == ballY) printf("O");

            // Dibuja la paleta del jugador (izquierda)
            else if (x == 1 && (y >= playerY && y < playerY + 4)) printf("|");

            // Dibuja la paleta de la computadora (derecha)
            else if (x == WIDTH - 2 && (y >= computerY && y < computerY + 4)) printf("|");

            else printf(" ");

            if (x == WIDTH - 1) printf("#");
        }
        printf("\n");
    }

    for (int i = 0; i < WIDTH + 2; i++) printf("#");
    printf("\n");
    printf("Jugador: %d | Computadora: %d\n", scorePlayer, scoreComputer);
}

void input() {
    if (_kbhit()) {
        char ch = _getch();
        if (ch == 'w' && playerY > 0) playerY--;
        if (ch == 's' && playerY < HEIGHT - 4) playerY++;
        if (ch == 'x') gameOver = 1;
    }
}

void logic() {
    // Movimiento de la pelota
    ballX += ballDirX;
    ballY += ballDirY;

    // Colisión de la pelota con las paredes superior e inferior
    if (ballY <= 0 || ballY >= HEIGHT - 1) {
        ballDirY *= -1;
    }

    // Colisión con la paleta del jugador
    if (ballX == 2 && (ballY >= playerY && ballY < playerY + 4)) {
        ballDirX *= -1;
    }

    // Colisión con la paleta de la computadora
    if (ballX == WIDTH - 3 && (ballY >= computerY && ballY < computerY + 4)) {
        ballDirX *= -1;
    }

    // IA de la computadora (se mueve hacia la posición vertical de la pelota)
    if (ballDirX > 0) {
        if (computerY + 2 < ballY && computerY < HEIGHT - 4) computerY++;
        if (computerY + 2 > ballY && computerY > 0) computerY--;
    }

    // Sistema de puntuación
    if (ballX <= 0) {
        scoreComputer++;
        setup();
    }
    if (ballX >= WIDTH - 1) {
        scorePlayer++;
        setup();
    }
}

int main() {
    setup();
    while (!gameOver) {
        draw();
        input();
        logic();
        
        // Simulación de retraso (Frame Rate)
        clock_t start = clock();
        while (clock() < start + 60000) {} // Ajusta este número para cambiar la velocidad
    }
    return 0;
}