#include <SDL2/SDL.h>
#include <iostream>
#include <vector>

const int SCREEN_WIDTH = 600;
const int SCREEN_HEIGHT = 600;
const int BOARD_SIZE = 3;

SDL_Window* window = nullptr;
SDL_Renderer* renderer = nullptr;

char board[BOARD_SIZE][BOARD_SIZE] = { {' ', ' ', ' '}, {' ', ' ', ' '}, {' ', ' ', ' '} };
char currentPlayer = 'X';
char cpu = 'O';
char human = 'X';
bool gameRunning = true;

// Dibuja el tablero en pantalla
void drawBoard() {
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);

    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    int step = SCREEN_WIDTH / BOARD_SIZE;
    for (int i = 1; i < BOARD_SIZE; ++i) {
        SDL_RenderDrawLine(renderer, i * step, 0, i * step, SCREEN_HEIGHT);
        SDL_RenderDrawLine(renderer, 0, i * step, SCREEN_WIDTH, i * step);
    }

    for (int row = 0; row < BOARD_SIZE; ++row) {
        for (int col = 0; col < BOARD_SIZE; ++col) {
            int x = col * step + step / 2;
            int y = row * step + step / 2;
            if (board[row][col] == 'X') {
                SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
                SDL_RenderDrawLine(renderer, x - 30, y - 30, x + 30, y + 30);
                SDL_RenderDrawLine(renderer, x + 30, y - 30, x - 30, y + 30);
            } else if (board[row][col] == 'O') {
                SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
                // Dibujo simplificado de un círculo (un punto central para el ejemplo)
                SDL_RenderDrawPoint(renderer, x, y); 
            }
        }
    }
    SDL_RenderPresent(renderer);
}

// Verifica si alguien ha ganado
bool checkWin(char player) {
    for (int i = 0; i < BOARD_SIZE; ++i) {
        if (board[i][0] == player && board[i][1] == player && board[i][2] == player) return true;
        if (board[0][i] == player && board[1][i] == player && board[2][i] == player) return true;
    }
    if (board[0][0] == player && board[1][1] == player && board[2][2] == player) return true;
    if (board[0][2] == player && board[1][1] == player && board[2][0] == player) return true;
    return false;
}

// Minimax para la CPU (dificultad invencible)
int minimax(bool isMax) {
    if (checkWin(cpu)) return 10;
    if (checkWin(human)) return -10;
    
    bool isFull = true;
    for(int r=0; r<BOARD_SIZE; ++r) {
        for(int c=0; c<BOARD_SIZE; ++c) {
            if(board[r][c] == ' ') isFull = false;
        }
    }
    if (isFull) return 0;

    if (isMax) {
        int best = -1000;
        for (int i = 0; i < BOARD_SIZE; ++i) {
            for (int j = 0; j < BOARD_SIZE; ++j) {
                if (board[i][j] == ' ') {
                    board[i][j] = cpu;
                    best = std::max(best, minimax(false));
                    board[i][j] = ' ';
                }
            }
        }
        return best;
    } else {
        int best = 1000;
        for (int i = 0; i < BOARD_SIZE; ++i) {
            for (int j = 0; j < BOARD_SIZE; ++j) {
                if (board[i][j] == ' ') {
                    board[i][j] = human;
                    best = std::min(best, minimax(true));
                    board[i][j] = ' ';
                }
            }
        }
        return best;
    }
}

void bestMove() {
    int bestVal = -1000;
    int bestRow = -1;
    int bestCol = -1;
    for (int i = 0; i < BOARD_SIZE; ++i) {
        for (int j = 0; j < BOARD_SIZE; ++j) {
            if (board[i][j] == ' ') {
                board[i][j] = cpu;
                int moveVal = minimax(false);
                board[i][j] = ' ';
                if (moveVal > bestVal) {
                    bestRow = i;
                    bestCol = j;
                    bestVal = moveVal;
                }
            }
        }
    }
    if (bestRow != -1 && bestCol != -1) board[bestRow][bestCol] = cpu;
}

// Maneja la interacción táctil en SDL2
void handleTouchEvents() {
    SDL_Event e;
    while (SDL_PollEvent(&e)) {
        if (e.type == SDL_QUIT) {
            gameRunning = false;
        }
        else if (e.type == SDL_MOUSEBUTTONDOWN && currentPlayer == human) {
            int x = e.button.x;
            int y = e.button.y;
            int step = SCREEN_WIDTH / BOARD_SIZE;

            int col = x / step;
            int row = y / step;

            if (board[row][col] == ' ') {
                board[row][col] = human;
                if (checkWin(human)) {
                    std::cout << "¡Ganaste!" << std::endl;
                    gameRunning = false;
                } else {
                    currentPlayer = cpu;
                    bestMove();
                    if (checkWin(cpu)) {
                        std::cout << "La CPU gana..." << std::endl;
                        gameRunning = false;
                    }
                    currentPlayer = human;
                }
            }
        }
    }
}

int main(int argc, char* args[]) {
    SDL_Init(SDL_INIT_VIDEO);
    window = SDL_CreateWindow("Tic Tac Toe", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    while (gameRunning) {
        handleTouchEvents();
        drawBoard();
        SDL_Delay(16); // ~60 FPS
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}