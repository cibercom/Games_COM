// VazBreak a BreakOut game by PhilVaz
// Full Screen GDI game
// Apr 17, 2003

// HEADER FILE ///////////////////////////////////////////////

// SOUNDS

#define SOUND_HIT1       100
#define SOUND_HIT2       101
#define SOUND_HIT3       102
#define SOUND_MISS       103
#define SOUND_PADDLE     104
#define SOUND_SERVE      105
#define SOUND_SIDE       106
#define SOUND_TOP        107

// ICON

#define ICON_VAZGAMES    200
