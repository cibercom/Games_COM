// Timer.c
// Functions for manipulating timers.
// Created 22/10/05 by Nick Oakley
#include "Timer.h"


void Timer_Start( void )
{
}

void Timer_Stop( void )
{
}

void Timer_GetValue( float* pfTimerVal )
{
}

