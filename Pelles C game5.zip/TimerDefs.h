// TimerDefs.h
// Definitions for Timer module.
// Created 22/10/05 by Nick Oakley
#ifndef TIMERDEFS_H
#define TIMERDEFS_H

typedef struct tag_TIMER {

	float	fSeconds;
	

} TIMER;


#endif // TIMERDEFS_H

