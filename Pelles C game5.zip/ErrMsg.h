// ErrMsg.h
// Wrapper for using MessageBox to display a generic error message.
// Created 13/09/05

#ifndef ERRMSG_H
#define ERRMSG_H

#include <windows.h>



void ErrMsg( HWND hWnd, LPSTR szMsg );



#endif // ERRMSG_H
