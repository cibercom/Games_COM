var mtg_sound = memory_tiles_game_sound(),
	mtg_board = memory_tiles_game_board(),
	mtg_ui = memory_tiles_game_ui();
	
mtg_ui.setDefaultSize();
	


